# CAPM Risk-Return Analysis (Python Project)

This project analyzes the risk and return of 20 selected Indian stocks using the Capital Asset Pricing Model (CAPM). It was built using Python libraries like `yfinance`, `pandas`, `numpy`, and `matplotlib`.

## 📈 What It Does:
- Calculates Beta, Alpha, and Expected Returns using CAPM
- Compares CAPM-predicted return vs actual historical return
- Backtests a ₹1.5 Cr portfolio across Banking, FMCG, Defence, and other sectors
- Visualizes cumulative returns from 2019 to 2024

## 🛠 Tools Used:
- Python 3.9+
- Libraries: `pandas`, `numpy`, `yfinance`, `matplotlib`, `statsmodels`
- Data Source: Yahoo Finance (via yfinance)

## 📊 Key Insights:
- Stocks like BEL and HAL outperformed CAPM expectations
- CAPM is more accurate for stable sectors like Banking and FMCG
- Suggested a diversified portfolio for moderate-risk investors

## 🔗 Screenshots

### 🔹 1. Normalized Prices of Sector-Wise Stocks
![Normalized Prices](charts/normalized_prices.png)

### 🔹 2. Daily Returns of Sector-Wise Stocks
![Daily Returns](charts/daily_returns.png)

### 🔹 3. Beta Plot – ICICIBANK vs NIFTY
![ICICI Beta](charts/icici_beta.png)

### 🔹 4. Beta Plot – ITC vs NIFTY
![ITC Beta](charts/itc_beta.png)

### 🔹 5. Beta Plot – RELIANCE vs NIFTY
![Reliance Beta](charts/reliance_beta.png)

### 🔹 6. CAPM vs Actual Returns – Bar Chart
![CAPM Bar](charts/capm_vs_actual_bar.png)

### 🔹 7. CAPM vs Actual Returns – Scatter Plot
![CAPM Scatter](charts/capm_vs_actual_scatter.png)

### 🔹 8. Backtested Portfolio Growth (2019–2024)
![Portfolio Growth](charts/portfolio_growth.png)

### 🔹 9. Recommended Portfolio Allocation
![Pie Chart](charts/portfolio_pie.png)

## 💡 Author:
Vinesh Nayaka  
[LinkedIn Profile](https://www.linkedin.com/in/your-link)
